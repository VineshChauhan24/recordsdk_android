package com.cgfay.cainfilter.type;

/**
 * 缩放类型
 * Created by cain on 17-7-26.
 */
public enum ScaleType {
    CENTER_INSIDE,
    CENTER_CROP,
    FIT_XY
}