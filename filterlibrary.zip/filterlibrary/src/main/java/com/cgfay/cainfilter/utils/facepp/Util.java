package com.cgfay.cainfilter.utils.facepp;

/**
 * Created by cain on 17-7-31.
 */

public class Util {
    public static String API_KEY = "CWRZSPs2gj3K7wQ8KCkFi8dHyLSje5yT";
    public static String API_SECRET = "k9dOS2d4PZmsjjMgv2W0CAkSIXTTp3TM";
}
