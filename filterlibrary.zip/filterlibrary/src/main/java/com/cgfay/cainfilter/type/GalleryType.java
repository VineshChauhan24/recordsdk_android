package com.cgfay.cainfilter.type;

/**
 * Created by cain.huang on 2017/9/28.
 */
public enum GalleryType {
    AUDIO, // gif表情包
    PICTURE, // 拍照
    VIDEO, // 视频
    GIF
}
