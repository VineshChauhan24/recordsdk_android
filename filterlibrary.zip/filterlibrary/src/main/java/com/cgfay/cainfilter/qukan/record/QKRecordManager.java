package com.cgfay.cainfilter.qukan.record;

import android.opengl.EGLContext;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;

import com.cgfay.cainfilter.multimedia.MediaEncoder;
import com.cgfay.cainfilter.qukan.AudioData;

import java.lang.annotation.Target;
import java.lang.ref.WeakReference;


public class QKRecordManager {
    private static final String TAG = "QKRecordManager";
    private static final boolean VERBOSE = true;

    public static final int RECORD_WIDTH = 1080;
    public static final int RECORD_HEIGHT = 1440;


    // 初始化录制器
    static final int MSG_INIT_RECORDER = 0;
    // 开始录制
    static final int MSG_START_RECORDING = 1;
    // 帧可用
    static final int MSG_FRAME_AVAILABLE = 2;
    // 渲染帧
    static final int MSG_DRAW_FRAME = 3;
    // 渲染帧
    static final int MSG_DRAW_AUDIO = 13;
    // 停止录制
    static final int MSG_STOP_RECORDING = 4;
    // 暂停录制
    static final int MSG_PAUSE_RECORDING = 5;
    // 继续录制
    static final int MSG_CONTINUE_RECORDING = 6;
    // 设置帧率
    static final int MSG_FRAME_RATE = 7;
    // 是否允许录制高清视频
    static final int MSG_HIGHTDEFINITION = 8;
    // 是否允许录制
    static final int MSG_ENABLE_AUDIO = 9;
    // 退出
    static final int MSG_QUIT = 10;
    // 设置渲染Texture的宽高
    static final int MSG_SET_TEXTURE_SIZE = 11;
    // 设置预览大小
    static final int MSG_SET_DISPLAY_SIZE = 12;

    // 录制线程
    private QKRecordManager.RecordThread mRecordThread;

    private String mOutputPath;

    private static QKRecordManager mInstance;

    public static QKRecordManager getInstance() {
        if (mInstance == null) {
            mInstance = new QKRecordManager();
        }
        return mInstance;
    }

    public QKRecordManager() {}

    /**
     * 初始化录制线程
     */
    synchronized public void initThread() {
        if (mRecordThread == null) {
            mRecordThread = new QKRecordManager.RecordThread();
            mRecordThread.start();
            mRecordThread.waitUntilReady();
            Log.d(TAG,"initThread");
        }
    }

    /**
     * 销毁线程
     */
    synchronized public void destoryThread() {
        Log.d(TAG,"destoryThread");
        if (mRecordThread != null) {
            Handler handler = mRecordThread.getHandler();
            if (handler != null) {
                handler.sendMessage(handler.obtainMessage(MSG_QUIT));
            }
            mRecordThread = null;
            Log.d(TAG,"destoryThread1");
        }
    }


    /**
     * 初始化录制器，此时耗时大约200ms左右，不能放在跟渲染线程同一个Looper里面
     * @param width
     * @param height
     * @param listener
     */
    public void initRecorder(int width, int height, MediaEncoder.MediaEncoderListener listener) {
        Log.d(TAG,"initRecord2");
        Handler handler = mRecordThread.getHandler();
        if (handler != null) {
            Log.d(TAG,"initRecord21");

            handler.sendMessage(handler.obtainMessage(MSG_INIT_RECORDER, width, height, listener));
        }
    }

    /**
     * 设置渲染Texture的宽高
     * @param width
     * @param height
     */
    public void setTextureSize(int width, int height) {
        Handler handler = mRecordThread.getHandler();
        if (handler != null) {
            handler.sendMessage(handler.obtainMessage(MSG_SET_TEXTURE_SIZE, width, height));
        }
    }

    /**
     * 设置预览大小
     * @param width
     * @param height
     */
    public void setDisplaySize(int width, int height) {
        Handler handler = mRecordThread.getHandler();
        if (handler != null) {
            handler.sendMessage(handler.obtainMessage(MSG_SET_DISPLAY_SIZE, width, height));
        }
    }

    /**
     * 开始录制
     * @param sharedContext EGLContext上下文包装类
     */
    public void startRecording(EGLContext sharedContext) {
        Log.d(TAG,"startRecording");
        Handler handler = mRecordThread.getHandler();
        if (handler != null) {
            handler.sendMessage(handler.obtainMessage(MSG_START_RECORDING, sharedContext));
        }
    }


    /**
     * 帧可用
     */
    public void frameAvailable() {
        Handler handler = mRecordThread.getHandler();
        if (handler != null) {
            handler.sendMessage(handler.obtainMessage(MSG_FRAME_AVAILABLE));
        }
    }

    /**
     * 发送渲染指令
     * @param texture 当前Texture
     * @param timeStamp 时间戳
     */
    synchronized public void drawRecorderFrame(int texture, long timeStamp) {
        Handler handler = mRecordThread.getHandler();
        if (handler != null) {
            handler.sendMessage(handler
                    .obtainMessage(MSG_DRAW_FRAME, texture, 0 /* unused */, timeStamp));
        }
    }

    /**
     * 发送渲染指令
     * @param data 当前音频流
     */
    synchronized public void drawAudio(AudioData data) {
        Handler handler = mRecordThread.getHandler();
        if (handler != null) {
                        handler.sendMessage(handler
                    .obtainMessage(MSG_DRAW_AUDIO, data));
        }
    }
    /**
     * 停止录制
     */
    synchronized public void stopRecording() {
        if (mRecordThread == null) {
            return;
        }
        Handler handler = mRecordThread.getHandler();
        if (handler != null) {
            handler.sendMessage(handler.obtainMessage(MSG_STOP_RECORDING));
        }
    }


    /**
     * 暂停录制
     */
    public void pauseRecording() {
        Handler handler = mRecordThread.getHandler();
        if (handler != null) {
            handler.sendMessage(handler.obtainMessage(MSG_PAUSE_RECORDING));
        }
    }

    /**
     * 继续录制
     */
    public void continueRecording() {
        Handler handler = mRecordThread.getHandler();
        if (handler != null) {
            handler.sendMessage(handler.obtainMessage(MSG_CONTINUE_RECORDING));
        }
    }


    /**
     * 设置帧率
     * @param frameRate
     */
    public void setFrameRate(int frameRate) {
        Handler handler = mRecordThread.getHandler();
        if (handler != null) {
            handler.sendMessage(handler.obtainMessage(MSG_FRAME_RATE, frameRate));
        }
    }


    /**
     * 是否允许录制高清视频
     * @param enable
     */
    public void enableHighDefinition(boolean enable) {
        Handler handler = mRecordThread.getHandler();
        if (handler != null) {
            handler.sendMessage(handler.obtainMessage(MSG_HIGHTDEFINITION, enable));
        }
    }

    /**
     * 是否允许录音
     * @param enable
     */
    public void setEnableAudioRecording(boolean enable) {
        Handler handler = mRecordThread.getHandler();
        if (handler != null) {
            handler.sendMessage(handler.obtainMessage(MSG_ENABLE_AUDIO, enable));
        }
    }

    /**
     * 获取输出路径
     * @return
     */
    public String getOutputPath() {
        return mOutputPath;
    }

    /**
     * 设置输出路径
     * @param path
     */
    public void setOutputPath(String path) {
        mOutputPath = path;
        QKEncoderManager.getInstance().setOutputPath(path);
        Log.d("path:",path);
    }

    /**
     * 录制线程
     */
    private static class RecordThread extends Thread {

        // 录制线程Handler回调
        private QKRecordManager.RecordHandler mHandler;

        private Object mReadyFence = new Object();
        private boolean mReady;


        @Override
        public void run() {
            Looper.prepare();
            synchronized (mReadyFence) {
                mHandler = new QKRecordManager.RecordHandler(this);
                mReady = true;
                mReadyFence.notify();
            }
            Log.d(TAG,"run");
            Looper.loop();
            if (VERBOSE) {
                Log.d(TAG, "Record thread exiting");
            }

            synchronized (mReadyFence) {
                Log.d(TAG,"QUIT");

                // 释放资源
                QKEncoderManager.getInstance().release();
                mReady = false;
                mHandler = null;
            }
        }

        /**
         * 等待线程结束
         */
        void waitUntilReady() {
            synchronized (mReadyFence) {
                while (!mReady) {
                    try {
                        mReadyFence.wait();
                    } catch (InterruptedException ie) {

                    }
                }
            }
        }

        /**
         * 初始化录制器
         * @param width
         * @param height
         * @param listener
         */
        void initRecorder(int width, int height, MediaEncoder.MediaEncoderListener listener) {
            Log.d(TAG,"initRecord4");
            if (VERBOSE) {
                Log.d(TAG, "init recorder");
            }

            synchronized (mReadyFence) {
                QKEncoderManager.getInstance().initRecorder(width, height, listener);
            }
        }

        /**
         * 设置渲染Texture的宽高
         * @param width
         * @param height
         */
        void setTextureSize(int width, int height) {
            if (VERBOSE) {
                Log.d(TAG, "setTextureSize");
            }
            synchronized (mReadyFence) {
                QKEncoderManager.getInstance().setTextureSize(width, height);
            }
        }

        /**
         * 设置预览大小
         * @param width
         * @param height
         */
        void setDisplaySize(int width, int height) {
            if (VERBOSE) {
                Log.d(TAG, "setDisplaySize");
            }
            synchronized (mReadyFence) {
                QKEncoderManager.getInstance().setDisplaySize(width, height);
            }
        }

        /**
         * 开始录制
         * @param eglContext EGLContext上下文包装类
         */
        void startRecording(EGLContext eglContext) {
            Log.d(TAG,"startRecording");
            if (VERBOSE) {
                Log.d(TAG, " start recording");
            }
            synchronized (mReadyFence) {
                QKEncoderManager.getInstance().startRecording(eglContext);
            }
        }


        /**
         * 帧可用
         */
        void frameAvailable() {
            if (VERBOSE) {
                Log.d(TAG, "frame available");
            }
            synchronized (mReadyFence) {
                QKEncoderManager.getInstance().frameAvailable();
            }
        }

        /**
         * 发送渲染指令
         * @param currentTexture 当前Texture
         * @param timeStamp 时间戳
         */
        long oldTime = -1;
        void drawRecordingFrame(int currentTexture, long timeStamp) {
            if(oldTime < timeStamp){
                oldTime = timeStamp;
            }else{
                timeStamp = oldTime + 1;
                oldTime = timeStamp;
            }
            timeStamp = timeStamp * 1000;


            if (VERBOSE) {
                Log.d(TAG, "draw recording frame");
            }
            synchronized (mReadyFence) {
                QKEncoderManager.getInstance().drawRecorderFrame(currentTexture, timeStamp);
            }
        }

        /**
         * 发送渲染指令
         * @param data 当前音频
         */
        void drawAudioData(AudioData data) {

            if (VERBOSE) {
                Log.d(TAG, "drawAudioData frame");
            }
            synchronized (mReadyFence) {
                QKEncoderManager.getInstance().drawAudioData(data);
            }
        }

        /**
         * 停止录制
         */
        void stopRecording() {
            if (VERBOSE) {
                Log.d(TAG, "stop recording");
            }
            synchronized (mReadyFence) {
                QKEncoderManager.getInstance().stopRecording();
            }
        }


        /**
         * 暂停录制
         */
        void pauseRecording() {
            if (VERBOSE) {
                Log.d(TAG, "pause recording");
            }
            synchronized (mReadyFence) {
                QKEncoderManager.getInstance().pauseRecording();
            }
        }

        /**
         * 继续录制
         */
        void continueRecording() {
            if (VERBOSE) {
                Log.d(TAG, "continue recording");
            }
            synchronized (mReadyFence) {
                QKEncoderManager.getInstance().continueRecording();
            }
        }


        /**
         * 设置帧率
         * @param frameRate
         */
        void setFrameRate(int frameRate) {
            if (VERBOSE) {
                Log.d(TAG, "set frame rate: " + frameRate);
            }
            synchronized (mReadyFence) {
                QKEncoderManager.getInstance().setFrameRate(frameRate);
            }
        }


        /**
         * 是否允许录制高清视频
         * @param enable
         */
        void enableHighDefinition(boolean enable) {
            if (VERBOSE) {
                Log.d(TAG, "enable highDefinition ? " + enable);
            }

            synchronized (mReadyFence) {
                QKEncoderManager.getInstance().enableHighDefinition(enable);
            }
        }

        /**
         * 是否允许录音
         * @param enable
         */
        void setEnableAudioRecording(boolean enable) {
            if (VERBOSE) {
                Log.d(TAG, "enable audio recording ? " + enable);
            }
            synchronized (mReadyFence) {
                QKEncoderManager.getInstance().setEnableAudioRecording(enable);
            }
        }

        /**
         * 获取Handler
         */
        public QKRecordManager.RecordHandler getHandler() {
            return mHandler;
        }
    }

    /**
     * 录制线程Handler回调
     */
    private static class RecordHandler extends Handler {

        private WeakReference<QKRecordManager.RecordThread> mWeakRecordThread;

        public RecordHandler(QKRecordManager.RecordThread thread) {
            mWeakRecordThread = new WeakReference<RecordThread>(thread);
        }

        @Override
        public void handleMessage(Message msg) {
            int what = msg.what;
            QKRecordManager.RecordThread thread = mWeakRecordThread.get();
            if (thread == null) {
                Log.w(TAG, "RecordHandler.handleMessage: encoder is null");
                return;
            }
            Log.d(TAG,"handleMessage1:" +what);

            switch (what) {
                // 初始化录制器
                case MSG_INIT_RECORDER:
                    Log.d(TAG,"initRecord3");
                    thread.initRecorder(msg.arg1, msg.arg2,
                            (MediaEncoder.MediaEncoderListener) msg.obj);

                    break;

                // 开始录制
                case MSG_START_RECORDING:
                    thread.startRecording((EGLContext) msg.obj);
                    break;

                // 帧可用
                case MSG_FRAME_AVAILABLE:
                    thread.frameAvailable();
                    break;

                // 渲染帧
                case MSG_DRAW_FRAME:
                    thread.drawRecordingFrame(msg.arg1, (Long) msg.obj);
                    break;
                //音频
                case MSG_DRAW_AUDIO:
                    AudioData data = (AudioData)msg.obj;
                    thread.drawAudioData(data);
                    break;

                // 停止录制
                case MSG_STOP_RECORDING:
                    thread.stopRecording();
                    break;

                // 暂停录制
                case MSG_PAUSE_RECORDING:
                    thread.pauseRecording();
                    break;

                // 继续录制
                case MSG_CONTINUE_RECORDING:
                    thread.continueRecording();
                    break;

                // 设置帧率
                case MSG_FRAME_RATE:
                    thread.setFrameRate((Integer) msg.obj);
                    break;

                // 是否允许高清录制
                case MSG_HIGHTDEFINITION:
                    thread.enableHighDefinition((Boolean) msg.obj);
                    break;

                // 是否允许录音
                case MSG_ENABLE_AUDIO:
                    thread.setEnableAudioRecording((Boolean) msg.obj);
                    break;

                // 退出线程
                case MSG_QUIT:
                    removeCallbacksAndMessages(null);
                    Looper.myLooper().quit();
                    break;

                // 设置渲染Texture的宽高
                case MSG_SET_TEXTURE_SIZE:
                    thread.setTextureSize(msg.arg1, msg.arg2);
                    break;

                // 设置预览的大小
                case MSG_SET_DISPLAY_SIZE:
                    thread.setDisplaySize(msg.arg1, msg.arg2);
                    break;

                default:
                    throw new RuntimeException("Unhandled msg what = " + what);
            }
            Log.d(TAG,"handleMessage2");

        }
    }
}
