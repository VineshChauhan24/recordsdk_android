package com.cgfay.cainfilter.qukan;

import android.content.Context;
import android.util.AttributeSet;
import android.view.SurfaceView;

public class VideoSurface extends SurfaceView {

    public VideoSurface(Context context) {
        super(context);
    }

    public VideoSurface(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public VideoSurface(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

}
