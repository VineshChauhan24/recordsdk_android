//
// Created by Administrator on 2018/3/9.
//

#include "HueFilter.h"

HueFilter::HueFilter(int *pixels, int width, int height) :IImageFilter(pixels, width, height) {

}

void HueFilter::processImage(int *destPixels) {

}

