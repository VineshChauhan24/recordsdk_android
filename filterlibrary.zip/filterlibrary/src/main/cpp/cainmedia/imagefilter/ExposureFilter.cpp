//
// Created by Administrator on 2018/3/9.
//

#include "ExposureFilter.h"

ExposureFilter::ExposureFilter(int *pixels, int width, int height)
        : IImageFilter(pixels, width, height) {

}

void ExposureFilter::processImage(int *destPixels) {

}
