//
// Created by Administrator on 2018/3/9.
//

#include "SharpnessFilter.h"

SharpnessFilter::SharpnessFilter(int *pixels, int width, int height)
        : IImageFilter(pixels, width, height) {

}

void SharpnessFilter::processImage(int *destPixels) {

}
