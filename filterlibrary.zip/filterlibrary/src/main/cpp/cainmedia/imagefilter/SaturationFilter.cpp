//
// Created by Administrator on 2018/3/9.
//

#include "SaturationFilter.h"

SaturationFilter::SaturationFilter(int *pixels, int width, int height)
        : IImageFilter(pixels, width, height) {

}

void SaturationFilter::processImage(int *destPixels) {

}
